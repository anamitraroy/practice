const r = require('request');

r({
    proxy: 'http://192.168.100.1:8081', 
    url:'https://www.google.co.in'}, 
    (err,resp,body) =>{
    if (err)
        console.log('some error : ', err);
    else
        console.log('body : ', body);
})