function add(x,y){
    return x+y;
}

function sub(x,y){
    return x-y;
}

console.log(add(10,20));
console.log(sub(10,20));