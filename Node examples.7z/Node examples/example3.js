const calc = require('./example2')

console.log(calc.add(10,20));
console.log(calc.sub(10,20));