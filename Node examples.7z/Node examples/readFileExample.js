const fs = require('fs');
fs.readFile('content.txt', 'utf8', (err, data) => {
    if(err) 
        throw err;
    else
        console.log(data);
});