
public class EventDemo implements Event {

	@Override
	public void doSomething() {
		System.out.println("First Implementation");

	}

	static class EventImpl implements Event { // inner class: class inside a class
		// static class can be made,instantiation will be diff then
		@Override
		public void doSomething() {
			System.out.println("Second Implementation");
		}

	}

	public void secondEvent() { // To access inner class object in outer class
		Event e = new EventImpl();
		e.doSomething();
	}

	public void thirdEvent() {
		class InnerEvent implements Event {

			@Override
			public void doSomething() {
				System.out.println("Third Implementation");
			}
		}
		Event e = new InnerEvent();
		e.doSomething();
	}

	public void oneMoreEvent() {
		Event e = new Event() {
			@Override
			public void doSomething() {
				System.out.println("Fourth Implementation");
			}
		};
		e.doSomething();
	}

	public void oneLastEvent() { //anonymous class
		Event e = () -> {
			System.out.println("Fifth Implementation");}; // implementation of lambda expression introduced in
			// java8
		e.doSomething();
	}

	public static void main(String[] args) {
		EventDemo demo = new EventDemo();
		demo.doSomething();
		demo.secondEvent();
		demo.thirdEvent();
		demo.oneMoreEvent();
		demo.oneLastEvent();

		// EventImpl impl = demo.new EventImpl(); //different syntax
		// impl.doSomething();

		// EventImpl impl = new EventDemo.EventImpl();
		// impl.doSomething();
	}

}
