import java.util.Base64;	//	this class consists of static methods to obtain encoders/decoders using Base64 scheme
import java.util.Base64.Encoder;
import java.util.Base64.Decoder;

public class Encoding {
	public static void main(String[] args) {
		String password = "P@ssw0rd";
		
		Encoder encoder = Base64.getEncoder();		//	creates an object of Encoder class
		
		String encoded = encoder.encodeToString(password.getBytes());	//	uses encodeToString method of Encoder class
		System.out.println(encoded);
		
		Decoder decoder = Base64.getDecoder();	//	creates an object of Decoder class
		
		String decoded = new String(decoder.decode(encoded));	//	decodes the previously encoded string
		System.out.println(decoded);
	}
}
