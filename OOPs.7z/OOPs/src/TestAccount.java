import com.lti.bank.AccountFactory;
import com.lti.bank.BalanceException;
import com.lti.bank.Bank;

public class TestAccount {

	public static void main(String[] args) {
		// Savings s= new Savings("Polo");
		// s.summary();
		// s.deposit(5000);

		Bank s = AccountFactory.openAccount("Polo", "Savings");
		
		int x = 300;
		
		s.statement();

		try {
			s.withdrawal(1000);
		} catch (BalanceException e) {
			//e.printStackTrace();		//	used by devs for troubleshooting. not shown to end-users
			//System.out.println(e);	//	prints exception type with message. used for logging [for system auditing]
			System.out.println(e.getMessage())	;	//	for End Users, only shows message
		}
		/*s.statement();

		s.deposit(7000);
		s.statement();
		s.withdrawal(2000);
		s.statement();
		s.withdrawal(4000);
		s.deposit(3500);
		s.statement();*/

	}

}
