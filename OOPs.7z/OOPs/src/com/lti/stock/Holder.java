package com.lti.stock;

public interface Holder {
	void viewQuote();
}
