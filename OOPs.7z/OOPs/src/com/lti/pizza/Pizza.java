package com.lti.pizza;

public interface Pizza {
	double typePrice();
	
	static Pizza SmallPizza =  () -> 50;
	static Pizza MediumPizza = () -> 75;
	static Pizza LargePizza = () -> 100;
	
	static void buildOrder(Pizza pizzaType, String...toppings ) {

	}
	
	
}
