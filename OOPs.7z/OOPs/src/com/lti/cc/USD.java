package com.lti.cc;

public class USD implements Currency {
	
	@Override
	public double dollarValue() {
		return 1;
	}
}
