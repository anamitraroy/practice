package com.lti.cc;

@FunctionalInterface
public interface Currency {

		double dollarValue();
		
		static void convert(Currency source, Currency target, double amount) {
			double rate = target.dollarValue() / source.dollarValue();
			System.out.println("Result: " + (amount*rate));
		}
		
		static Currency INR = () -> 70.50;
		static Currency AED = () -> 3.70;
		static Currency USD = () -> 1;
		
}
