package com.lti.mediaApp;
import java.util.*;

public class PaidUser extends FreeUser implements PaidMedia {
	
	String[] paidMediaList = {"Spotlight", "Avengers", "Inception"};
	
/*	String[]	totalMediaList = Arrays.copyOf(freeMediaList, freeMediaList.length + paidMediaList.length);
	System.arraycopy(paidMediaList, 0, totalMediaList, freeMediaList.length, paidMediaList.length);*/
	
	public void displayMedia() {
		super.displayMedia();
		for (String s2 : paidMediaList) {
			System.out.println(s2);
		}
	}
	
	
/*	public void selectMedia() {
		Scanner reader = new Scanner(System.in);
		System.out.println("Give your option number: ");
		int n = reader.nextInt();
		if((n-1)>= totalMediaList.length) {
			System.out.println("Please enter a valid choice.");
			reader.close();
		}
		else {
			System.out.println("You are now watching "+ totalMediaList[n-1] + ".");
			reader.close();
		}
	}*/
}
