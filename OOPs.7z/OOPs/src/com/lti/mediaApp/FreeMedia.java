package com.lti.mediaApp;

public interface FreeMedia {
	abstract void displayMedia();
	abstract void selectMedia();
}
