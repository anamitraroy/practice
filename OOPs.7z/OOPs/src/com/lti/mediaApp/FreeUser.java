package com.lti.mediaApp;
import java.util.Scanner;

public class FreeUser implements FreeMedia {
	String[] freeMediaList = {"Jurassic Park", "Harry Potter", "Bahubali"};
	
	
	public void displayMedia() {
		System.out.println("Films available to you are: ");
		for (String s1 : freeMediaList) {
			System.out.println(s1);
		}
	}
	
	public void selectMedia() {
		Scanner reader = new Scanner(System.in);
		System.out.println("Give your option number: ");
		int n = reader.nextInt();
		if((n-1)>= freeMediaList.length) {
			System.out.println("Please enter a valid choice.");
			reader.close();
		}
		else {
			System.out.println("You are now watching "+ freeMediaList[n-1] + ".");
			reader.close();
		}
	}
	
}
