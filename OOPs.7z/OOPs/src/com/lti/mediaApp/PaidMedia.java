package com.lti.mediaApp;

public interface PaidMedia {
	void displayMedia();
}
