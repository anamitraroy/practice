package com.lti.bank;

public class Savings extends Account {

	public Savings() {
	}

	public Savings(String holder) {		// opens account with holder name and init balance of 1000
		super(holder, MIN_SAV_BAL);
		txns = new Transaction[10];
		
		txns[idx++] = new Transaction("CR", MIN_SAV_BAL, MIN_SAV_BAL);
				
			//Transaction t = new Transaction("CR", MIN_SAV_BAL, MIN_SAV_BAL);
			//txns[idx] = t;
			//idx++;
	}

	@Override
	public void withdrawal(double amount) throws BalanceException {
		if (amount <= (balance - MIN_SAV_BAL)) {
			balance -= amount;
			txns[idx++] = new Transaction("DR", amount, balance);
		}
		else
			throw new BalanceException("Insufficient Funds!");
	}

}
