package com.lti.bank;

public final class AccountFactory {
	private AccountFactory() { // extended class not required
		// make default constructor private

	}

	public static Bank openAccount(String holder, String type) {
		Bank acnt = null;
		if (type.equalsIgnoreCase("savings"))
			acnt = new Savings(holder);
		else
			acnt = new Current(holder);

		return acnt;
	}

}
