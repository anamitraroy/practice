package com.lti.bank;
public class Current extends Account {
	private double overdraft;

	public Current() {
	}

	// Constructor with name string and constant values for initial balance and overdraft limit
	public Current(String holder) {
		super(holder, INIT_CUR_BAL);
		this.overdraft = OD_LIMIT;
	}

	@Override
	public void summary() {
		super.summary();			// prints summary lines common to all accounts, defined in parent class
		System.out.println("Overdraft : " + overdraft);
	}

	@Override
	public void deposit(double amount) {
		overdraft += amount;
		if(overdraft > OD_LIMIT) {
			balance += (overdraft - OD_LIMIT);
			overdraft = OD_LIMIT;
		}
	}

	@Override
	public void withdrawal(double amount) throws BalanceException {
		if (amount < balance) {
			balance -= amount;
		}
		else if (amount <= balance + overdraft) {
			overdraft -= (amount - balance);
			balance = MIN_CUR_BAL;
		}
		else
			throw new BalanceException("Insufficient Funds!");
	}

}
