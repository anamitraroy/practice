package com.lti.bank;

public class Customer {
	private int custNo;
	private String custName;
	private double creditLimit;

	// Default constructor
	public Customer() {

	}

	// Parametrized constructor
	public Customer(int custNo, String custName, double creditLimit) {
		this.custNo = custNo;
		this.custName = custName;
		this.creditLimit = creditLimit;
	}
	
	public void init (int no, String name, double limit) {
		custNo = no;
		custName = name;
		creditLimit = limit;
	}

	// Public Method
	public void custslip() {
		System.out.println("Customer number = " + custNo);
		System.out.println("Customer Name = " + custName);
		System.out.println("Credit Limit = " + creditLimit);
	}
}
