package com.lti.emp;

public abstract class Employee {
	private int empNo;
	private String empName;
	private double salary;

	private static int autogen;

	static { // static initializer block
		System.out.println("Class Employee loaded...");
		autogen = 1001;
	}

	// Default constructor
	public Employee() {

	}

	// Parameterized constructor
	public Employee(String empName, double salary) {
		this.empNo = autogen++;
		this.empName = empName;
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	// Public method
	public void payslip() {
		System.out.println("Emp No: " + empNo);
		System.out.println("Emp Name: " + empName);
		System.out.println("Salary: " + salary);
	}
}
