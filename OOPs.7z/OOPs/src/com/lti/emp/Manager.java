package com.lti.emp;
public class Manager extends Employee {
	private double incentives;

	public Manager() {
	}

	public Manager(String empName, double salary, double incentives) {
		super(empName, salary);
		this.incentives = incentives;
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getSalary() {
		// TODO Auto-generated method stub
		return super.getSalary() + incentives;
	}

	@Override
	public void payslip() {
		// TODO Auto-generated method stub
		super.payslip();
		System.out.println( "Incentives: " + incentives);
	}
	
	
}
