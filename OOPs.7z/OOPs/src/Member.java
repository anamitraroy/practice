

public class Member {
	private String name;
	private String book;
	
	public String getName() {
		return name;
	}

	public String getBook() {
		return book;
	}

	public void setBook(String book) {
		this.book = book;
	}

	public Member() {

	}
	
	public Member(String memName) {
		this.name = memName;
	}
	
	public void status() {
		if(book == null) {
			System.out.println(name+" has not issued any book.");
		}
		else System.out.println(name +" has issued the book "+book +".");
	}
	
}
