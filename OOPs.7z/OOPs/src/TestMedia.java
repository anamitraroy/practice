import com.lti.mediaApp.*;


public class TestMedia {
	public static void main(String[] args) {
		FreeUser f1 = new FreeUser();
		f1.displayMedia();
		f1.selectMedia();
		
//		System.out.println("------------------------------------------------------------------");
		/*PaidUser p1 = new PaidUser();
		p1.displayMedia();*/
		//p1.selectMedia();
				
	}
	
}
