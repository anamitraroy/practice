

public interface Event {
	void doSomething();

}
