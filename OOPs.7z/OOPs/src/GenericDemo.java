
public class GenericDemo<Z> { // whatever you specify in <> will decide the type of object
	private Z data; // Z will be used to define the type of object as per requirement

	public GenericDemo(Z data) {
		this.data = data;
	}

	public Z getData() {
		return data;
	}

	public void setData(Z data) {
		this.data = data;
	}

	public static void main(String[] args) {
		GenericDemo<String> d1 = new GenericDemo<String>("Hello");
		System.out.println(d1.getData());

		GenericDemo<Integer> d2 = new GenericDemo<Integer>(123); 
		// used Integer here instead of int as generics only support objects, not primitives
		System.out.println(d2.getData());
		
		GenericDemo d3 = new GenericDemo(100);
		d3.setData("Hey");
		System.out.println(d3.getData());
	}
}
