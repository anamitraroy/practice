
import static com.lti.cc.Currency.*;

public class TestCurrencyConverter {
	public static void main(String[] args) {
		/*CurrencyConverter cc = new CurrencyConverter();
		cc.convert(new INR(), new USD(), 100);
		cc.convert(new USD(),	 new AED(), 100);*/
		
		convert(INR, USD, 7050);
		convert(AED, INR, 100);
		convert(USD, AED, 100);
	}

}
