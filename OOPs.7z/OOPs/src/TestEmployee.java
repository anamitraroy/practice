import com.lti.emp.Employee;
import com.lti.emp.Executive;
import com.lti.emp.Manager;

public class TestEmployee {

	public static void main(String[] args) {

		Executive exec = new Executive("Lili", 16500, 3000);

		Manager mgr = new Manager("Lolo", 12500, 1500);
		
		showSalary(exec);
		showSalary(mgr);
	}

	private static void showSalary(Employee e) {
		if(e instanceof Manager)	// abstraction that provides info about current instance during runtime
			System.out.println("Manager Salary: " + e.getSalary());
		else
			System.out.println("Executive Salary: " + e.getSalary());
	}
	
/*	// Method Overloading
	private static void showSalary(Executive exec) {
		System.out.println("Executive salary: " + exec.getSalary());
	}

	private static void showSalary(Manager mgr) {
		System.out.println("Manager salary: " + mgr.getSalary());
	}
*/
}
