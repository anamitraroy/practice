import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class PersonReflection {
	public static void main(String[] args) {
		Person p = new Person("Polo", 21);

		Class pc = p.getClass();
		System.out.println(pc.getName());

		Constructor[] constructors = pc.getConstructors();
		System.out.println("-- List of constructors");
		for (Constructor constructor : constructors) {
			System.out.println(constructor);
		}

		Method[] methods = pc.getMethods();
		System.out.println("-- List of Methods");
		for (Method method : methods) {
			System.out.println(method);
		}
		
		Method[] decMethods = pc.getDeclaredMethods(); // only gets methods declared in Person class
		System.out.println("-- List of declared methods");
		for (Method method : decMethods) {
			System.out.println(method);
		}

		Field[] fields = pc.getFields();	// doesn't show any fields here as both fields are private
		System.out.println("-- List of fields");
		for (Field field : fields) {
			System.out.println(field);
		}
		
		Field[] decFields = pc.getDeclaredFields();	// doesn't show any fields here as both fields are private
		System.out.println("-- List of fields");
		for (Field field : decFields) {
			System.out.println(field);
		}
	}
}
