
public class Car {
	private String model;
	private String[] features;

	public Car(String model, String...features) { //variable arguments
		this.model = model;
		this.features = features;

	}

	public void specs() {
		System.out.println("Features of " + model);
		for (String feature : features)
			System.out.println(feature);
	}

	public static void main(String[] args) {
		String[] falto = { "Keyless Entry", "Power Steering", "Power Window" };
		Car alto = new Car("Suzuki Alto", falto);

		String[] fbal = { "Keyless", "ABS", "Pano Roof", "Air Bags", "Cruise Control" };
		Car baleno = new Car("Suzuki Baleno", fbal);

		alto.specs();
		baleno.specs();
	}
}