
public class Person {
	private String name;
	private int age;

	// Default Constructor
	public Person() {
		// Constructor chaining - calls another constructor on same object with matching
		// signature
		this("Anonymous", -1);
	}

	// Parameterized Constructor
	public Person(String pname, int page) {
		name = pname;
		age = page;
	}

	public void print() {
		System.out.println("Name: " + name + "\tAge: " + age);
	}

	/*
	 * public static void main(String[] args) { Person p1 = new Person("Polo", 21);
	 * // p1.init("Polo", 21); p1.print();
	 * 
	 * Person p2 = new Person(); // Instantiation p2.print(); }
	 */

	@Override
	public String toString() {
		return "Name: " + name + "\tAge: " + age;
	}

	@Override
	public void finalize() throws Throwable { //lowest priority thread
		
		System.out.println("The person is no more!");
	}
	
	

	public boolean equals(Object obj) {
		if (obj instanceof Person) {
			return true;
		} else {
			return false;
		}
	}
}
