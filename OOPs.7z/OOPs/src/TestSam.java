
public class TestSam {
	
	public void testHello() {
		Hello h = (name) -> "Hello " + name;	//	method implemented by lambda expression
		System.out.println(h.sayHello("Anamitra"));
		System.out.println(h.sayBye("Anushree"));
	}

	public static void main(String[] args) {
		TestSam sam = new TestSam();
		sam.testHello();
		System.out.println(Hello.max(10, 20));

	}

}
