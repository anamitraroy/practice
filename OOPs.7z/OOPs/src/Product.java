
public class Product {
	public String Name;
	public double Price;
	public int stock;

	// Default constructor
	public Product() {

	}

	// Parameterized constructor
	public Product(String Name, double Price, int stock) {
		this.Name = Name;
		this.Price = Price;
		this.stock = stock;
	}
	

}
