
@FunctionalInterface	//	Has EXACTLY ONE abstract method
public interface Hello {
	String sayHello(String name);
	
	default String sayBye(String name) {
		return "Bye " + name;
	}
	
	static int max (int a, int b) {
		return a>b?a:b;
	}
	
	String toString();
	
}

