import com.lti.stock.Broker;
import com.lti.stock.Exchange;
import com.lti.stock.Holder;
import com.lti.stock.StockSingleton;

public class TestStock {

	public static void main(String[] args) {
		// Stock LTI = new Stock();
	

		Holder H =StockSingleton.getStock();

		Broker B = StockSingleton.getStock();

		Exchange E = StockSingleton.getStock();

		H.viewQuote();

		B.getQuote();

		E.setQuote();

		System.out.println(H == B);
		System.out.println(H == E);

	}

}
