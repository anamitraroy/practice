import com.lti.bank.Customer;

public class TestCustomer {

	public static void main(String[] args) {
		Customer c1 = new Customer(111, "Anu", 50555);
		c1.custslip();

		Customer c2 = new Customer(222, "Fred", 60000);
		c2.custslip();

		Customer c3 = new Customer();
		c3.init(333, "Diana", 70000);
		c3.custslip();

	}

}
