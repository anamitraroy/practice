public class Book {
	private String title;
	private String mbr;
	
	public Book (String title) {
		this.title = title;
	}
	
	public void status() {
		if(mbr == null) {
			System.out.println("The book " + title + " is available.");
		}
		else System.out.println("The book " + title + " is not available");
	}
	
	public void issueBook(Member memName) {
		if(mbr == null) {
			mbr = memName.getName();
			memName.setBook(title);
			System.out.println("The book " + title + " is issued to " + mbr);
		}
		else System.out.println("This book is not available");
	}
	
	public void returnBook(Member memName) {
		if(mbr != null) {
			System.out.println("The book " + title + " has been returned by " + mbr);
			mbr = null;
			memName.setBook(null);
		}
		else System.out.println("The book " + title + "  has not been issued yet.");
	}
	
}
