
public class TestPerson {

	public static void main(String[] args) {
		/*
		 * Person p1 = new Person("Polo", 21); p1.print();
		 * 
		 * Person p2 = new Person("lolo", 25);
		 * 
		 * System.out.println(p1.hashCode()); System.out.println(p2.hashCode());
		 * System.out.println(p1);// calls to String() implicitly
		 * System.out.println(p2);
		 * 
		 * System.out.println(p1.equals(p2)); }
		 */
		Person p = null;
		for (int c = 1; c <= 5; c++) {
			p = new Person();
		}
		System.gc(); //request gc 
	}
}
