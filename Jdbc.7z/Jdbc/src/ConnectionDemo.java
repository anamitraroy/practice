import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDemo {

	public static void main(String[] args) {
		
		//String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn = null;
		
		try {
			/*Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection(url, "HR", "Newuser123");*/

			conn = JdbcFactory.getConnection();
			
			System.out.println("Connected successfully");
			
			DatabaseMetaData meta = conn.getMetaData();
			System.out.println(meta.getDatabaseProductName());
			System.out.println(meta.getDatabaseProductVersion());
			System.out.println(meta.getDriverName());
			System.out.println(meta.getDriverVersion());
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

}
