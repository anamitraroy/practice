
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementDemo {

	public static void main(String[] args) {
		String sql = "insert into person values ('Polo', 21, 'Pune')";
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection(); 	//getting connection
			
			// creating statement to fire hard-coded/fixed query
			Statement stmt = conn.createStatement();
			
			stmt.executeUpdate(sql); 		// performing DML Operation
			System.out.println("Record inserted");
			
		} catch (SQLException e) {
			System.out.println("Record insertion failed due to.....");
			e.printStackTrace();
		} finally {
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
