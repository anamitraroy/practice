import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PrecompiledDemo {

	public static void main(String[] args) {
		// ? is known as a place-holder, position starts from 1
		String sql = "insert into person values (?, ?, ?)"; // cmd line arg thru Run->Run Configurations->Arguments. No
																																						// quotes, no commas
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);

			// replacing place-holders with data
			stmt.setString(1, args[0]);
			stmt.setInt(2, Integer.parseInt(args[1]));
			stmt.setString(3, args[2]);

			stmt.executeUpdate(); // performing DML
			System.out.println("Record Inserted.");
		} catch (NumberFormatException e) {
			System.out.println("Insertion failed due to ... ");
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
						conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}

	}

}
