import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdatableRecords {
	public static void main(String[] args) {
		String sql = "select name, age, city from person";	//	updatable will NOT!!! work with * in select
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
			ResultSet rs = stmt.executeQuery(sql);
			
			/*rs.absolute(2);
			rs.updateString(1, "From JDBC");
			rs.updateInt(2, 55);
			rs.updateRow();
			System.out.println("1 row updated.");*/
			
			rs.afterLast();
			rs.moveToInsertRow();
			rs.updateString(1, "Testing2");
			rs.updateInt(2, 30);
			rs.updateString(3, "Ahmedabad");
			rs.insertRow();
			System.out.println("1 row inserted.");
			
			/*ResultSetMetaData meta = rs.getMetaData();
			for (int i = 1; i <= meta.getColumnCount(); i++) 
				System.out.print(meta.getColumnLabel(i) + "\t");
			
			System.out.println();
			
			while (rs.next())
				//System.out.printf("%-20s\t%3d\t%-20s\n", rs.getString(1), rs.getInt("age"), rs.getString("city"));
				System.out.println(rs.getString(1) + "\t" + rs.getString("age") + "\t"+ rs.getString(3));*/
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
						conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
}
