import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

//	callable statement is for invoking procedures stored in DB
public class CallableDemo {

	public static void main(String[] args) {
		Connection conn = null;
		
		try {
			conn = JdbcFactory.getConnection();
			CallableStatement stmt = conn.prepareCall("{call getAge(?, ?)}");
			
			stmt.setString(1,  "Polo");
			//	have to specify the OUT parameter index and type before statement can be executed
			stmt.registerOutParameter(2, Types.INTEGER);
			stmt.execute();
			
			System.out.println("Age: " + stmt.getInt(2));
		} catch (SQLException e) {
			System.out.println("Query failed due to.. ");
			e.printStackTrace();
		} finally {
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}

	}

}
