
public class TestingAlpha {
	public static void demo() {
		System.out.println("From A");
	}

}
