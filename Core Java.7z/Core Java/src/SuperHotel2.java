public class SuperHotel2 {
	public static void main(String[] args) {
		
	}
}