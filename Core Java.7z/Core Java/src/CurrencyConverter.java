
public class CurrencyConverter {

}
