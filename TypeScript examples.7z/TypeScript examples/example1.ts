//  example for classes and constructors in TypeScript
class Person {

    private name: string;
    private age: number;

    constructor(personName: string, personAge: number){
        this.name = personName;
        this.age = personAge;
    }

    info () {
        console.log(this.name);
        console.log(this.age);
    }
}

let person1: Person = new Person("Anamitra", 23);
person1.info();