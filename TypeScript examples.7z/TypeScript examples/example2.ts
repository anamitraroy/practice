//  example for enums in TypeScript

enum Season {
    SUMMER, RAINY, WINTER
}

let currentSeason: Season = Season.SUMMER;

console.log(Season[currentSeason]);