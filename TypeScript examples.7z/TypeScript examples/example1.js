var Person = /** @class */ (function () {
    function Person(personName, personAge) {
        this.name = personName;
        this.age = personAge;
    }
    Person.prototype.info = function () {
        console.log(this.name);
        console.log(this.age);
    };
    return Person;
}());
var person1 = new Person("Anamitra", 23);
person1.info();
