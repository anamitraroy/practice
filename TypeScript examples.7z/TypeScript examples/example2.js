//  example for enums in TypeScript
var Season;
(function (Season) {
    Season[Season["SUMMER"] = 0] = "SUMMER";
    Season[Season["RAINY"] = 1] = "RAINY";
    Season[Season["WINTER"] = 2] = "WINTER";
})(Season || (Season = {}));
var currentSeason = Season.SUMMER;
console.log(Season[currentSeason]);
