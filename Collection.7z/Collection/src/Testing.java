
public interface Testing {
	
	int a =10;
	
	static public void display() {
		System.out.println("method defined in Interface :O ");
	};
	
	public void showSomething();
}
