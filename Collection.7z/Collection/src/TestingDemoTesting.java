
public class TestingDemoTesting {

	public static void main(String[] args) {
		TestingDemo t = new TestingDemo();
		t.showSomething();
		
	}

}
