
public class TestingDemo implements Testing {
	
	String nameToShow;
	Integer number;
	static int a = 200;
	
	public void showSomething() {
		System.out.println("Showing something from sub class");
	}
	
	public void display() {
		System.out.println("Display from sub class");
	}
	
}
