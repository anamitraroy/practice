import java.util.HashMap;
import java.util.Set;

public class MapDemo {
	public static void main(String[] args) {
		HashMap<String, String> maps = new HashMap<>();
		maps.put("java", "duke");
		maps.put("jack", "jill");
		maps.put("scott", "tiger");
		maps.put("jack", "rose");
		
		Set<String> keys = maps.keySet();
		for (String key : keys) {
			System.out.println(key +": " + maps.get(key));
		}
		/*System.out.println(maps.get("java"));
		System.out.println(maps.get("scott"));
		System.out.println(maps.get("jack"));*/
	}
}
