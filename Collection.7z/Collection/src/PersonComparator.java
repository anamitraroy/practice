import java.util.Comparator;

public class PersonComparator implements Comparator<Person> {

	//	if p1>p2, +ve int, if p1<p2 -ve int, if p1 = p2 then 0
	@Override
	public int compare(Person p1, Person p2) {		//	return type int rather than bool as there can be p1=p2
		return p1.getAge() - p2.getAge();
	}
	
}
