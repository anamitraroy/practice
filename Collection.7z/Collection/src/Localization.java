import java.util.Locale;
import java.util.ResourceBundle;

public class Localization {

	public static void main(String[] args) {
		
		Locale hi = new Locale("hi");
		ResourceBundle bundle = ResourceBundle.getBundle("greeting", hi);
		
		System.out.println(bundle.getString("message"));
		System.out.println(bundle.getString("greeting"));

	}

}
