import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.Vector;

public class CollectionDemo {
	public static void main(String[] args) {
		Vector<String> v = new Vector<String>();
		v.add("Apple");
		v.add("Microsoft");
		v.add("Oracle");
		v.add(1, "Google");
		
		System.out.println("-- Traversing over vector using for-loop");
		for (int i = 0; i < v.size(); i++) 
			System.out.println(v.get(i));
		
		System.out.println("-- Traversing over vector using for-each");
		for (String elem: v)
			System.out.println(elem);
		
		System.out.println("-- Traversing over vector using iterator");
		Iterator<String> itr = v.iterator();
		while (itr.hasNext())
			System.out.println(itr.next());
		
		LinkedList<String> lst = new LinkedList<>();
		lst.add("Facebook");
		lst.add("Google");
		lst.add("Apple");
		
		v.addAll(lst);		//	merging collections
		System.out.println("-- Traversing merged vector using for-each");
		for (String elem : v)
			System.out.println(elem);		//	getting duplicate elements
		
		//	Converting collections
		HashSet<String> set = new HashSet<>(v);		//	converting vector v to HashSet
		System.out.println("-- Traversing over hashset using for each");
		for (String elem : set) {
			System.out.println(elem);		//	Set doesn't return duplicate elements
		}
		
		TreeSet<String> tree = new TreeSet<>(set);		//	sorts set
		System.out.println("-- Traversing over treeset using for-each");
		for(String elem : tree)
			System.out.println(elem);
	}
}
