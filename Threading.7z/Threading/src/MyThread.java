
public class MyThread extends Thread {
	private int count;

	@Override
	public void run() {
		Thread t = Thread.currentThread();
		String name = t.getName();
		for(int c=1; c<=50; c++)
			System.out.println(name + ": "+ ++ count);
	}
	
	public static void main(String[] args) {
		MyThread m1 = new MyThread();
		MyThread m2 = new MyThread();
		MyThread m3 = new MyThread();
		
		m1.setName("alpha");
		m2.setName("beta");
		m3.setName("gamma");
		
		
		//	by default priority is NORM_PRIORITY
		m1.setPriority(MAX_PRIORITY);		//	will finish first
		m3.setPriority(MIN_PRIORITY);		//	will finish last
		
		m1.start();
		m2.start();
		m3.start();
		
		Thread t = Thread.currentThread();
		String name = t.getName();
		for(int c=1; c<=50; c++)
			System.out.println(name + ": "+ ++ c);
		
	}
	
	
}
