import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerialDemo {
	public static void main(String[] args) throws Exception {
		Person p = new Person("Polo", 21);
		System.out.println(p);
		
		String path = "D:/2019Workspace/pers.dat";
		
		//	serialization
		FileOutputStream fos = new FileOutputStream(path);
		ObjectOutputStream ostream = new ObjectOutputStream(fos);
		
		ostream.writeObject(p);		//	object serialized
		ostream.close();
		
		//	deserialization
		ObjectInputStream istream = new ObjectInputStream(new FileInputStream(path));
		Object dp = istream.readObject(); 	//	Object deserialized
		System.out.println(dp);
		istream.close();
	}
}
