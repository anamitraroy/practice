import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FastCopy {

	public static void main(String[] args) {
		FileInputStream inFile = null;
		FileOutputStream outFile = null;
		BufferedInputStream inBuffer = null;
		BufferedOutputStream outBuffer = null;
		
		try {
			inFile = new FileInputStream("D:/2019Workspace/vs.exe");		//	approx 45 MB
			outFile = new FileOutputStream("D:/2019Workspace/newvs.exe");
			inBuffer = new BufferedInputStream(inFile, 1024*16);				//	16 KB buffer
			outBuffer = new BufferedOutputStream(outFile, 1024*16);		//	16 KB buffer
			
			int ch = 0;
			long ms1 = System.currentTimeMillis();
			while (true) {
				ch = inBuffer.read();
				if(ch == -1)
					break;
				outBuffer.write(ch);
			}
			long ms2 = System.currentTimeMillis();
			System.out.println("File copied successfully in "+(ms2 - ms1) +" ms.");
		} catch (FileNotFoundException e) {
			System.out.println(e);
		} catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				inFile.close();
				outFile.close();
				inBuffer.close();
				outBuffer.close();
			} catch (Exception e) {}
		}

	}

}
