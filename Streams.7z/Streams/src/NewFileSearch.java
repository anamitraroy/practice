import java.io.File;

public class NewFileSearch {

	public void findFile(String name, File file) {
		File[] list = file.listFiles();		//	creates array of File objects
		if (list != null)							//	if no file/dir returned, will exit
			for (File allFiles : list) {		//	searches for each result from list array
				if (allFiles.isDirectory()) {
					findFile(name, allFiles);		//	recursively calls findFile function
				}
				else if (name.equals(allFiles.getName()))
					System.out.println(allFiles.getPath());
			}
	}
	
	public static void main(String[] args) {
		NewFileSearch fs = new NewFileSearch();
		String directory = "D:/";
		fs.findFile("url.txt", new File(directory));
	}

}
