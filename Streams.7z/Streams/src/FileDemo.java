import java.io.File;
import java.util.*;

public class FileDemo {
	public static void main(String[] args) {
		String path = "D:/2019Workspace/url.txt";

		File file = new File(path);
		if (file.exists()) {
			System.out.println(file.getName());
			System.out.println(file.getPath());

			if (file.isFile()) {
				System.out.println(file.canRead());
				System.out.println(file.canWrite());
				System.out.println(file.length());
				//	System.out.println(file.lastModified());		//	gives millisecond time
				Date dt = new Date(file.lastModified());
				System.out.println(dt);
			} else {
				String[] content = file.list();
				System.out.println("Content of Directory");
				for (String item : content) {
					System.out.println(item);
				}
			}
		} else
			System.out.println("File does not exist.");
	}
}
