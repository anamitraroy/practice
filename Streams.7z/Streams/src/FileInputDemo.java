import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputDemo {

	public static void main(String[] args) {
		String path = "D:/2019Workspace/song.txt";
		//	int c = 0;
		FileInputStream istream = null;
		
		try {
			istream = new FileInputStream(path);
			byte [] bar = new byte[istream.available()];
			istream.read(bar);
			System.out.println(new String(bar));
			
			/*while(true) {
				c = istream.read();		//	we get ASCII characters, as reading is byte by byte
				if (c == -1) break;
				System.out.print((char) c);
			}*/
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(istream != null)
				try {
					istream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			
		}

	}

}
