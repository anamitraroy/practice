import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {
	public static void main(String[] args) {
		String path = "D:/2019Workspace/song.txt";
		String line = null;
		FileReader reader = null;
		BufferedReader buffer = null;

		try {
			reader = new FileReader(path);					//	file reader reads the file
			buffer = new BufferedReader(reader);		//	buffer is wrapped over file reader, stores in buffer mem

			while (true) {
				line = buffer.readLine();
				if (line == null)
					break;						
				System.out.println(line);							//	prints until file is finished
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {																	//	closes the resources of buffer and reader
				buffer.close();
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}
}
