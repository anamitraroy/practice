import java.io.File;
import java.util.*;

public class FileSearch {

	public static void main(String[] args) {
		search("url.txt", "D:/2019Workspace");
	}

	public static void search(String fileName, String pathName) {
		String name = fileName;
		String path = pathName;
		File file = new File(path);

		File[] content = file.listFiles();
		// System.out.println("Content of Directory");
		for (File item : content) {
			if (item.getName() == name) {
				System.out.println(item.getPath());
			} else {
				if (item.isDirectory()) {
					search(name, item.getPath());
				}
			}
		}
	}
}
