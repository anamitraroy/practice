
	 $(document).ready(function() {
			$("#loginForm").validate({
				rules: {
					userName: "required",
					password: "required"
				},
				messages:{
					userName: "Please enter a username",
					password: "Please provide a password"
				}
			});
			
			$('#submitBtn').click(function() {
				$("#loginForm").valid();
			});
	}); 

 