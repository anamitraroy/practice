
$(document).ready(function() {
		$("#incomeDetailsForm").validate({
			
			submitHandler: function(form) {  
                if ($(form).valid()) {
                	alert("submitted");
                	form.submit(); 	
                }
                return false; // prevent normal form posting
         	},
         	
			rules: {
				employmentType:"required",
				monthlyIncome:{
					required:true,
					  minlength:1,
					  maxlength:10,
					  number:true
				},
				userId:{
					required:true,
					  minlength:1,
					  maxlength:100,
					  number:true
				},
				typeOfEmployment : "required",
				organisation:"required",
				retirementAge:{
					required:true,
					  minlength:1,
					  maxlength:2,
					  number:true
				},
			},

			messages: {
				userId:"Please enter userId",
				employmentType: "Please enter typeOfEmployment",
				monthlyIncome: "Please enter monthlyIncome",
				organisation:"Please enter organisation",
				retirementAge:"Please enter retirement age"
			}
			
		});

		$('#SubmitForm').click(function() {
        	$("incomeDetailsForm").valid();
    	}); 

	});

