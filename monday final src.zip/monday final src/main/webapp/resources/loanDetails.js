
$(document).ready(function() {
		$("#LoanApplicationForm").validate({
			
			submitHandler: function(form) {  
                if ($(form).valid()) {
                	alert("submitted");
                	form.submit(); 	
                }
                return false; // prevent normal form posting
         	},
         	
			rules: {
				propertyName:"required",
				propertyLocation:"required",
				estimatedAmount:{
					  required:true,
					  minlength:1,
					  maxlength:10,
					  number:true
				},
				duration:{
					  required:true,
					  minlength:1,
					  maxlength:300,
					  number:true
				},
				loanAmount:{
					  required:true,
					  minlength:1,
					  maxlength:10,
					  number:true
				},
			},

			messages: {
				propertyName:"Please enter property name",
				propertyLocation: "Please enter property location",
				estimatedAmount: "Please enter estimated amount",
				duration:"Please enter the duartion",
				loanAmount:"Please enter loan amount"
			}
			
		});

		$('#SubmitForm').click(function() {
        	$("LoanApplicationForm").valid();
    	}); 

	});
