
	$(document).ready(function(){
		$("#eligilibilty_calculator").validate({
			rules:{
				monthlyincome: {
					required: true,
					number: true,
					min: 0,
					max: 1000000000
				}
			},
			messages: {
				monthlyincome: "Please enter a valid income"
			},
		});	
		$('#eligibilitySubmit').click(function() {
	        $("#eligilibilty_calculator").valid();
	    });
		
		$("#monthly_emi").validate({
			rules:{
				monthduration: {
					required: true,
					number: true,
					min: 0,
					max: 300
				}
			},
			messages: {
				monthduration: "Please enter a valid duration"
			},
		});	
		$('#emiSubmit').click(function() {
	        $("#monthly_emi").valid();
	    });
		
	});
        
	
	var Loanamount;
			function calculate(monthlyincome) {
                if(monthlyincome >=0 && monthlyincome < 1000000000)
                {
                    Loanamount = 60*(0.60 * parseInt(monthlyincome)); 
                    Loanamount= Loanamount.toFixed(2);
                    document.getElementById("loan-amount").value = Loanamount ;
                }
            }
            function emi(monthduration){
                 if (monthduration > 0 && monthduration <= 300){
                    var rate = 8.5/(12*100);      //  monthly interest rate
                      var principal = Loanamount;
                    
                      var EMI = principal*rate*((Math.pow((1+rate) ,(monthduration)))/( Math.pow ((1+rate),(monthduration))-1));
                      EMI= EMI.toFixed(2);
                      document.getElementById("e").value = EMI;
                 }

            }
    