package com.lti.homeloan.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.homeloan.entity.ApplicationEntity;
import com.lti.homeloan.entity.UserEntity;
import com.lti.homeloan.entity.UserIncomeDetailsEntity;
import com.lti.homeloan.exception.UserAlreadyExistsException;

@Repository
public class UserDao extends GenericDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public UserEntity add(UserEntity register) throws UserAlreadyExistsException {
		return entityManager.merge(register);
	}
	
	@Transactional
	public void addIncomeDetails(UserIncomeDetailsEntity incomeDetails) {
		entityManager.persist(incomeDetails);
	}
	
	public UserIncomeDetailsEntity fetchUserIncomeDetails(UserEntity userEntity) {
		Query query = entityManager.createQuery("select userIncome from UserIncomeDetailsEntity as userIncome "
																+ "where userIncome.user.id = :userEntityId");
		return (UserIncomeDetailsEntity) query.setParameter("userEntityId", userEntity.getId()).getSingleResult();
	}
	
	public List<ApplicationEntity> fetchApplicationsByUser(UserEntity user) {
		Query query = entityManager.createQuery("select applications from ApplicationEntity as applications "
																+ "where applications.user like :userSent");
		query.setParameter("userSent", user);
		List<ApplicationEntity> applications = query.getResultList();
		return applications;
	}
}
