package com.lti.homeloan.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.lti.homeloan.entity.ApplicationEntity;
import com.lti.homeloan.entity.UserEntity;


@Repository
public class ApplicationDao {

	@PersistenceContext
	private EntityManager entityManager;

	public void add(ApplicationEntity application) {
		entityManager.persist(application);
	}

	public  List<ApplicationEntity> fetchAll() {
		return entityManager.createQuery("select applicationEntity from ApplicationEntity as applicationEntity").getResultList();
	}
}
