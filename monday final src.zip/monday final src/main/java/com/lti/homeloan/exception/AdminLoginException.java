package com.lti.homeloan.exception;

public class AdminLoginException extends RuntimeException {

	public AdminLoginException() {
		super();

	}

	public AdminLoginException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);

	}

	public AdminLoginException(String arg0, Throwable arg1) {
		super(arg0, arg1);

	}

	public AdminLoginException(String arg0) {
		super(arg0);

	}

	public AdminLoginException(Throwable arg0) {
		super(arg0);

	}
	
}
