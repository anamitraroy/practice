package com.lti.homeloan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.homeloan.dao.FileUploadDao;
import com.lti.homeloan.dao.GenericDao;
import com.lti.homeloan.dao.UserDao;
import com.lti.homeloan.dto.FileUploadDTO;
import com.lti.homeloan.dto.LoanApplicationDTO;
import com.lti.homeloan.dto.UserDTO;
import com.lti.homeloan.dto.UserIncomeDetailsDTO;
import com.lti.homeloan.entity.ApplicationEntity;
import com.lti.homeloan.entity.FileUploadEntity;
import com.lti.homeloan.entity.LoanEntity;
import com.lti.homeloan.entity.PropertyEntity;
import com.lti.homeloan.entity.UserEntity;
import com.lti.homeloan.entity.UserIncomeDetailsEntity;
import com.lti.homeloan.exception.UserAlreadyExistsException;

//import oracle.net.aso.l;

@Service
public class UserService {
		
	@Autowired
	private GenericDao genericDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private FileUploadDao  fileUploadDao;
	
	@Transactional
	public UserEntity register(UserDTO registerDTO) {		//	shouldn't be void. should return something for if-else for success or failure of register
		UserEntity newUser = new UserEntity();
		newUser.setFirstName(registerDTO.getFirstName());
		newUser.setLastName(registerDTO.getLastName());
		newUser.setMiddleName(registerDTO.getMiddleName());
		newUser.setEmailId(registerDTO.getEmailId());
		newUser.setPassword(registerDTO.getPassword());
		newUser.setAadharNo(registerDTO.getAadharNo());
		newUser.setPanNo(registerDTO.getPanNo());
		newUser.setMaritalStatus(registerDTO.getMaritalStatus());
		newUser.setDob(registerDTO.getDob());
		newUser.setGender(registerDTO.getGender());
		newUser.setMobileNo(registerDTO.getMobileNo());
		newUser.setQuestion(registerDTO.getQuestion());
		newUser.setAnswer(registerDTO.getAnswer());
		
		
		UserEntity createdUser;
		try {
			createdUser = (UserEntity) userDao.add(newUser);
		} catch (UserAlreadyExistsException e) {
			return null;
		}
		
		return createdUser;
		
	}
	
	@Transactional
	public void addIncomeDetails(UserIncomeDetailsDTO userIncomeDetailsDTO, UserEntity user) {
		UserIncomeDetailsEntity income=new UserIncomeDetailsEntity();
		
		income.setUser(user);
		income.setEmploymentType(userIncomeDetailsDTO.getEmploymentType());
		income.setMonthlyIncome(userIncomeDetailsDTO.getMonthlyIncome());
		income.setOrganisation(userIncomeDetailsDTO.getOrganisation());
		income.setRetirementAge(userIncomeDetailsDTO.getRetirementAge());
		
		genericDao.add(income);
	}
	
	@Transactional
	public PropertyEntity addPropertyDetails(LoanApplicationDTO loanApplicationDTO, UserEntity user) {
		PropertyEntity property=new PropertyEntity();
		
		property.setUser(user);
		property.setPropertyName(loanApplicationDTO.getPropertyName());
		property.setPropertyLocation(loanApplicationDTO.getPropertyLocation());
		property.setEstimatedAmount(loanApplicationDTO.getEstimatedAmount());
		
		PropertyEntity addedProperty = (PropertyEntity) genericDao.add(property);
		return addedProperty;
	}
	
	
	@Transactional
	public ApplicationEntity addApplicationDetails(LoanApplicationDTO loanApplicationDTO, UserEntity user, PropertyEntity property) {
		
		ApplicationEntity application=new ApplicationEntity();
		
		user.getId();
		
		double maxLoanAmount = 60 * (0.6 * userDao.fetchUserIncomeDetails(user).getMonthlyIncome());
		double rate = 8.5;			//	!!!! Hardcoded !!!!
		application.setUser(user);
		application.setMaximumLoanAmount(maxLoanAmount);
		application.setRequestedLoanAmount(loanApplicationDTO.getRequestedAmount());
		application.setRate(rate);
		application.setDuration(loanApplicationDTO.getDuration());
		application.setProperty(property);
		application.setIsSent(true);
		application.setIsVerified(false);
		application.setIsApproved(false);
		application.setIsRejected(false);
		
		ApplicationEntity currentApplication = (ApplicationEntity) genericDao.add(application);
		return currentApplication;
	}
	
	public List<ApplicationEntity> fetchApplicationsByUser(UserEntity user) {
		return userDao.fetchApplicationsByUser(user);
	}
	
	@Transactional
	public void fileUpload(FileUploadDTO fileUploadDTO, UserEntity user, ApplicationEntity application) {
		FileUploadEntity fileUploadEntity=new FileUploadEntity();
		
		fileUploadEntity.setUser(user);
		fileUploadEntity.setApplication(application);
		fileUploadEntity.setAadharCard(fileUploadDTO.getAadharCard().getOriginalFilename());
		fileUploadEntity.setPanCard(fileUploadDTO.getPanCard().getOriginalFilename());
		fileUploadEntity.setSalarySlip(fileUploadDTO.getSalarySlip().getOriginalFilename());
		fileUploadEntity.setLetterOfAgreement(fileUploadDTO.getLetterOfAgreement().getOriginalFilename());
		fileUploadEntity.setNoc(fileUploadDTO.getNoc().getOriginalFilename());
		fileUploadEntity.setAgreement(fileUploadDTO.getAgreement().getOriginalFilename());
		
		fileUploadDao.addFiles(fileUploadEntity);
	}
	
	public FileUploadEntity getFilesForUser (UserEntity user) {
		return fileUploadDao.fetch(user);
	}

}