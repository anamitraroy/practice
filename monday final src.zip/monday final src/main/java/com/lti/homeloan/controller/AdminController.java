package com.lti.homeloan.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lti.homeloan.dto.AdminLoginDTO;
import com.lti.homeloan.entity.AdminEntity;
import com.lti.homeloan.entity.ApplicationEntity;
import com.lti.homeloan.entity.FileUploadEntity;
import com.lti.homeloan.entity.LoanEntity;
import com.lti.homeloan.service.AdminService;

@Controller
@SessionAttributes("admin")
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping(path="/adminLogin", method=RequestMethod.POST)
	public String login(AdminLoginDTO loginDTO, Map<String, Object> model, HttpSession session) {
		AdminEntity admin = adminService.login(loginDTO);
		if(admin != null) {
			session.setAttribute("admin", admin);
			model.put("admin", admin);
			return "/adminDashboard.jsp";
		}
		else
			return "/loginError.jsp";
	}
	
	@RequestMapping(path="/fetchLoans", method=RequestMethod.GET)
	public String fetchApprovedLoans(Map<String, Object> model, HttpSession session) {
		AdminEntity admin = (AdminEntity) session.getAttribute("admin");
		if(admin != null) {
			List<LoanEntity> loans = adminService.fetchLoans();
			model.put("listOfLoans", loans);
			return "/adminViewLoans.jsp";
		}
		else 
			return "redirect:/adminLogin.jsp";
	}
	
	@RequestMapping(path="/fetchApplications", method=RequestMethod.GET)
	public String fetchPendingApplications(Map<String, Object> model, HttpSession session) {
		AdminEntity admin = (AdminEntity) session.getAttribute("admin");
		if(admin != null) {
			List<ApplicationEntity> applications = adminService.fetchPendingApplications();
			model.put("listOfApplications", applications);
			return "/adminViewApplications.jsp";
		}
		else 
			return "redirect:/adminLogin.jsp";
	}
	
	@RequestMapping(path="/viewSingleApplication", method=RequestMethod.GET)
	public String viewSingleApplication(Map<String, Object> model, 
														@RequestParam("applicationNo") int applicationNumber, 
																				HttpServletRequest request) {
		
		ApplicationEntity application = adminService.fetchSingleApplication(applicationNumber);
		FileUploadEntity documents = adminService.fetchDocuments(application);
				
		String appRoot = request.getServletContext().getRealPath("/");
		
		int userId = documents.getUser().getId();
		File srcFile1 = new File("d:/uploads/"+ userId +"-" + documents.getAadharCard());		
		File destFile1 = new File(appRoot + "/uploads/"+userId +"-" + documents.getAadharCard());
		
		File srcFile2 = new File("d:/uploads/" + documents.getPanCard());		
		File destFile2 = new File(appRoot + "/uploads/"+userId +"-" + documents.getPanCard());
		
		File srcFile3= new File("d:/uploads/" + documents.getSalarySlip());		
		File destFile3 = new File(appRoot + "/uploads/"+userId +"-" + documents.getSalarySlip());
		
		File srcFile4= new File("d:/uploads/" + documents.getLetterOfAgreement());
		File destFile4 = new File(appRoot + "/uploads/"+userId +"-" + documents.getLetterOfAgreement());
		
		File srcFile5= new File("d:/uploads/" + documents.getNoc());
		File destFile5 = new File(appRoot + "/uploads/"+userId +"-" + documents.getNoc());
		
		File srcFile6= new File("d:/uploads/" + documents.getAgreement());
		File destFile6 = new File(appRoot + "/uploads/"+userId +"-" + documents.getAgreement());
		
		System.out.println(appRoot);
		System.out.println(srcFile1.getName());
		System.out.println(destFile1.getName());
		System.out.println(srcFile2.getName());
		System.out.println(destFile2.getName());
		try {
			FileUtils.copyFile(srcFile1, destFile1);
			FileUtils.copyFile(srcFile2, destFile2);
			FileUtils.copyFile(srcFile3, destFile3);
			FileUtils.copyFile(srcFile4, destFile4);
			FileUtils.copyFile(srcFile5, destFile5);
			FileUtils.copyFile(srcFile6, destFile6);
		}
		catch (IOException e) {
			e.printStackTrace(); //if copy fails, throw an exception instead
		}
		
		model.put("currentApplication", application);
		model.put("documents", documents);
		return "/adminViewSingleApplication.jsp";
	}
	
	@RequestMapping(path="/verifyApplication", method=RequestMethod.GET)
	public String verifyApplication(@RequestParam("applicationNo") int applicationNumber) {
		adminService.verifyApplication(applicationNumber);
		return "/adminDashboard.jsp";
	}
	
	@RequestMapping(path="/approveApplication", method=RequestMethod.GET)
	public String approveApplication(@RequestParam("applicationNo") int applicationNumber) {
		adminService.approveApplication(applicationNumber);
		return "/adminApprovalSuccessful.jsp";
	}
	
	@RequestMapping(path="/rejectApplication", method=RequestMethod.GET)
	public String rejectApplication(@RequestParam("applicationNo") int applicationNumber) {
		adminService.rejectApplication(applicationNumber);
		return "/adminRejectionSuccessful.jsp";
	}
	
}
