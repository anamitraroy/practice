package com.lti.homeloan.test;

import java.text.DecimalFormat;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.lti.homeloan.dao.LoginDAO;
import com.lti.homeloan.dto.LoginDTO;
import com.lti.homeloan.entity.UserEntity;

public class LoginTest { 
	@Test
	public void loginTest() {
		
		LoginDTO dto = new LoginDTO();
		dto.setEmailId("eeeee@gmail.com");
		dto.setPassword("eeeeeeeee");
		
		ApplicationContext ctx = new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/spring-config.xml");
		LoginDAO dao = ctx.getBean(LoginDAO.class);
		
		UserEntity userEntity = dao.login(dto);
		System.out.println(userEntity.getEmailId());
		System.out.println(userEntity.getPassword());
		
	}
	
	@Test
	public void passwordUpdateTest() {
		LoginDTO dto = new LoginDTO();
		dto.setEmailId("tanu22@gmail.com");
		dto.setPassword("tanuTest2");
		
		ApplicationContext ctx = new FileSystemXmlApplicationContext("src/main/webapp/WEB-INF/spring-config.xml");
		LoginDAO dao = ctx.getBean(LoginDAO.class);
		dao.updatePassword(dto);		
	}
	
	@Test
	public void roundTest() {
		double test = 1243475357235.23568713647;
		DecimalFormat df = new DecimalFormat("#.##");
		System.out.println(df.format(test));
	}
}
